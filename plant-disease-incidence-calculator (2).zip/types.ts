export interface CalculationResult {
  id: number;
  plotNumber: string;
  stand: number;
  severity: number;
  diseasedPlant: number;
  incidence: number;
}
